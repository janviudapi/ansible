#!/usr/bin/python

from ansible.module_utils.basic import AnsibleModule
from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

def change_scsi_controller_type(module, vm_name):
    vcenter_host = module.params['vcenter_host']
    vcenter_user = module.params['vcenter_user']
    vcenter_password = module.params['vcenter_password']
    
    s = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
    s.verify_mode = ssl.CERT_NONE
    
    try:
        si = SmartConnect(host=vcenter_host, user=vcenter_user, pwd=vcenter_password, sslContext=s)
        content = si.content
        
        vm = get_vm_by_name(content, vm_name)
        
        if vm:
            changed = change_controller_type(vm)
            Disconnect(si)
            if changed:
                response = {'changed_vm': vm_name}
                module.exit_json(changed=True, meta=response)
            else:
                module.exit_json(changed=False, meta={'message': 'No change needed.'})
        else:
            Disconnect(si)
            module.fail_json(msg=f"Virtual machine with name '{vm_name}' not found.")
    except Exception as e:
        module.fail_json(msg=str(e))

def get_vm_by_name(content, vm_name):
    container = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
    for vm in container.view:
        if vm.name == vm_name:
            return vm
    return None

def change_controller_type(vm):
    changed = False
    spec = vim.vm.ConfigSpec()
    for device in vm.config.hardware.device:
        if isinstance(device, vim.vm.device.ParaVirtualSCSIController):
            if device.deviceInfo.summary != 'pvscsi':
                device.deviceInfo.summary = 'pvscsi'
                spec.deviceChange.append(vim.vm.device.VirtualDeviceSpec(
                    operation=vim.vm.device.VirtualDeviceSpec.Operation.edit,
                    device=device))
                changed = True
                break
    
    if changed:
        task = vm.ReconfigVM_Task(spec)
        task_result = WaitForTask(task)
        if task_result == vim.TaskInfo.State.success:
            return True
    return False

def WaitForTask(task):
    while task.info.state == vim.TaskInfo.State.running:
        time.sleep(2)
    return task.info.state

def main():
    module = AnsibleModule(
        argument_spec=dict(
            vcenter_host=dict(type='str', required=True),
            vcenter_user=dict(type='str', required=True),
            vcenter_password=dict(type='str', required=True, no_log=True),
            vm_name=dict(type='str', required=True)
        )
    )
    
    change_scsi_controller_type(module, module.params['vm_name'])

if __name__ == '__main__':
    main()
