#!/usr/bin/env python3

DOCUMENTATION = '''
---
module: custom_vm_scsi_info
short_description: Retrieve detailed SCSI controller information for a virtual machine using its ID
'''

from ansible.module_utils.basic import AnsibleModule
from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

def main():
    module = AnsibleModule(
        argument_spec=dict(
            vcenter_host=dict(type='str', required=True),
            vcenter_user=dict(type='str', required=True),
            vcenter_password=dict(type='str', required=True, no_log=True),
            vm_id=dict(type='str', required=True)
        )
    )
    
    vcenter_host = module.params['vcenter_host']
    vcenter_user = module.params['vcenter_user']
    vcenter_password = module.params['vcenter_password']
    vm_id = module.params['vm_id']
    
    s = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
    s.verify_mode = ssl.CERT_NONE
    
    try:
        si = SmartConnect(host=vcenter_host, user=vcenter_user, pwd=vcenter_password, sslContext=s)
        content = si.content
        vm = get_vm_by_id(content, vm_id)
        
        if vm:
            scsi_info = get_scsi_controllers(vm)
            Disconnect(si)
            module.exit_json(changed=False, meta=scsi_info)
        else:
            Disconnect(si)
            module.fail_json(msg=f"Virtual machine with ID '{vm_id}' not found.")
    except Exception as e:
        module.fail_json(msg=str(e))

def get_vm_by_id(content, vm_id):
    container = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
    for vm in container.view:
        if vm._moId == vm_id:
            return vm
    return None

def get_scsi_controllers(vm):
    scsi_controllers = []
    if vm.config and vm.config.hardware and vm.config.hardware.device:
        for device in vm.config.hardware.device:
            if isinstance(device, vim.vm.device.VirtualLsiLogicController):
                scsi_controller = {
                    'key': device.key,
                    'device_type': device.__class__.__name__,
                    'bus_number': device.busNumber,
                    'hot_add_remove': device.hotAddRemove,
                    'shared_bus': device.sharedBus,
                    'scsi_level': device.scsiCtlrUnitNumber,
                    'device_info': {
                        'label': device.deviceInfo.label,
                        'summary': device.deviceInfo.summary
                    }
                }
                scsi_controllers.append(scsi_controller)
            elif isinstance(device, vim.vm.device.ParaVirtualSCSIController):
                scsi_controller = {
                    'key': device.key,
                    'device_type': device.__class__.__name__,
                    'bus_number': device.busNumber,
                    'hot_add_remove': device.hotAddRemove,
                    'shared_bus': device.sharedBus,
                    'device_info': {
                        'label': device.deviceInfo.label,
                        'summary': device.deviceInfo.summary
                    }
                }
                scsi_controllers.append(scsi_controller)
    return scsi_controllers

if __name__ == "__main__":
    main()
