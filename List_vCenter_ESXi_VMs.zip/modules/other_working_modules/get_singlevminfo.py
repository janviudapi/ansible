#!/usr/bin/env python3

DOCUMENTATION = '''
---
module: custom_vm_info
short_description: Retrieve information about a single virtual machine from vCenter inventory
'''

from ansible.module_utils.basic import AnsibleModule
from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

def main():
    module = AnsibleModule(
        argument_spec=dict(
            vcenter_host=dict(type='str', required=True),
            vcenter_user=dict(type='str', required=True),
            vcenter_password=dict(type='str', required=True, no_log=True),
            vm_name=dict(type='str', required=True)
        )
    )
    
    vcenter_host = module.params['vcenter_host']
    vcenter_user = module.params['vcenter_user']
    vcenter_password = module.params['vcenter_password']
    vm_name = module.params['vm_name']
    
    s = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
    s.verify_mode = ssl.CERT_NONE
    
    try:
        si = SmartConnect(host=vcenter_host, user=vcenter_user, pwd=vcenter_password, sslContext=s)
        content = si.content
        vm = get_vm_by_name(content, vm_name)
        
        if vm:
            vm_info = {
                'id': vm._moId,
                'name': vm.name,
                'power_state': vm.runtime.powerState,
                'connection_state': vm.runtime.connectionState,
                'guest_fullname': vm.config.guestFullName,
                'num_cpus': vm.config.hardware.numCPU,
                'memory_size_mb': vm.config.hardware.memoryMB,
                'esxi_host': get_vm_esxi_host(vm),
                'cluster': get_vm_cluster(vm),
                'datastore': get_vm_datastore(vm),
                'folder': get_vm_folder(vm),
                'ip_addresses': get_vm_ip_addresses(vm)
            }
            Disconnect(si)
            module.exit_json(changed=False, meta=vm_info)
        else:
            Disconnect(si)
            module.fail_json(msg=f"Virtual machine '{vm_name}' not found.")
    except Exception as e:
        module.fail_json(msg=str(e))

def get_vm_by_name(content, vm_name):
    container = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
    for vm in container.view:
        if vm.name == vm_name:
            return vm
    return None

def get_vm_esxi_host(vm):
    if vm.runtime.host:
        return vm.runtime.host.name
    return None

def get_vm_cluster(vm):
    if vm.resourcePool:
        return vm.resourcePool.owner.name
    return None

def get_vm_datastore(vm):
    if vm.datastore:
        return vm.datastore[0].name
    return None

def get_vm_folder(vm):
    if vm.parent:
        return vm.parent.name
    return None

def get_vm_ip_addresses(vm):
    ip_addresses = []
    if vm.guest != None and vm.guest.net != None:
        for net in vm.guest.net:
            for ip in net.ipAddress:
                ip_addresses.append(ip.ipAddress)
    return ip_addresses

if __name__ == "__main__":
    main()
