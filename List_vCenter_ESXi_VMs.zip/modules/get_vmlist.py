#!/usr/bin/env python3

DOCUMENTATION = '''
---
module: custom_vm_list
short_description: Retrieve virtual machines list from vCenter inventory
'''

from ansible.module_utils.basic import AnsibleModule
from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

def main():
    module = AnsibleModule(
        argument_spec=dict(
            vcenter_host=dict(type='str', required=True),
            vcenter_user=dict(type='str', required=True),
            vcenter_password=dict(type='str', required=True, no_log=True)
        )
    )
    
    vcenter_host = module.params['vcenter_host']
    vcenter_user = module.params['vcenter_user']
    vcenter_password = module.params['vcenter_password']
    
    s = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
    s.verify_mode = ssl.CERT_NONE
    
    try:
        si = SmartConnect(host=vcenter_host, user=vcenter_user, pwd=vcenter_password, sslContext=s)
        content = si.content
        vms = get_all_objs(content, [vim.VirtualMachine])
        vm_list = []

        for vm in vms:
            vm_info = {
                'id': vm._moId,
                'name': vm.name,
                'power_state': vm.runtime.powerState,
                'connection_state': vm.runtime.connectionState,
                'guest_fullname': vm.config.guestFullName,
                'num_cpus': vm.config.hardware.numCPU,
                'memory_size_mb': vm.config.hardware.memoryMB,
                'esxi_host': get_vm_esxi_host(vm),
                'cluster': get_vm_cluster(vm),
                'datastore': get_vm_datastore(vm),
                'folder': get_vm_folder(vm),
                'ip_addresses': get_vm_ip_addresses(vm)
            }
            vm_list.append(vm_info)

        Disconnect(si)
        
        response = {'virtual_machines': vm_list}
        module.exit_json(changed=False, meta=response)
    except Exception as e:
        module.fail_json(msg=str(e))

def get_all_objs(content, vimtype):
    obj = {}
    container = content.viewManager.CreateContainerView(content.rootFolder, vimtype, True)
    for managed_object_ref in container.view:
        obj.update({managed_object_ref: managed_object_ref.name})
    return obj

def get_vm_esxi_host(vm):
    if vm.runtime.host:
        return vm.runtime.host.name
    return None

def get_vm_cluster(vm):
    if vm.resourcePool:
        return vm.resourcePool.owner.name
    return None

def get_vm_datastore(vm):
    if vm.datastore:
        return vm.datastore[0].name
    return None

def get_vm_folder(vm):
    if vm.parent:
        return vm.parent.name
    return None

def get_vm_ip_addresses(vm):
    ip_addresses = []
    if vm.guest and vm.guest.net:
        for net in vm.guest.net:
            if net.ipAddress:
                ip_addresses.extend(net.ipAddress)
    return ip_addresses

if __name__ == "__main__":
    main()
