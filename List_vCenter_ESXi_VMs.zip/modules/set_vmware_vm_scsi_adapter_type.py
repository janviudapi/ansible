#!/usr/bin/env python3

DOCUMENTATION = '''
---
module: custom_change_scsi_summary
short_description: Change SCSI type summary for a specific SCSI controller to "pvscsi"
'''

from ansible.module_utils.basic import AnsibleModule
from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

def main():
    module = AnsibleModule(
        argument_spec=dict(
            vcenter_host=dict(type='str', required=True),
            vcenter_user=dict(type='str', required=True),
            vcenter_password=dict(type='str', required=True, no_log=True),
            vm_id=dict(type='str', required=True),
            scsi_controller_key=dict(type='int', required=True)
        )
    )
    
    vcenter_host = module.params['vcenter_host']
    vcenter_user = module.params['vcenter_user']
    vcenter_password = module.params['vcenter_password']
    vm_id = module.params['vm_id']
    scsi_controller_key = module.params['scsi_controller_key']
    
    s = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
    s.verify_mode = ssl.CERT_NONE
    
    try:
        si = SmartConnect(host=vcenter_host, user=vcenter_user, pwd=vcenter_password, sslContext=s)
        content = si.content
        
        vm = get_vm_by_id(content, vm_id)
        
        if vm:
            changed = change_scsi_summary(vm, scsi_controller_key)
            Disconnect(si)
            if changed:
                response = {'changed_vm': vm.name}
                module.exit_json(changed=True, meta=response)
            else:
                module.exit_json(changed=False, meta={'message': 'No change needed.'})
        else:
            Disconnect(si)
            module.fail_json(msg=f"Virtual machine with ID '{vm_id}' not found.")
    except Exception as e:
        module.fail_json(msg=str(e))

def get_vm_by_id(content, vm_id):
    container = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
    for vm in container.view:
        if vm._moId == vm_id:
            return vm
    return None

def change_scsi_summary(vm, scsi_controller_key):
    changed = False
    if vm.config and vm.config.hardware and vm.config.hardware.device:
        for device in vm.config.hardware.device:
            if device.key == scsi_controller_key:
                if isinstance(device, vim.vm.device.ParaVirtualSCSIController):
                    if device.deviceInfo.summary != 'pvscsi':
                        device.deviceInfo.summary = 'pvscsi'
                        changed = True
    return changed

if __name__ == "__main__":
    main()
