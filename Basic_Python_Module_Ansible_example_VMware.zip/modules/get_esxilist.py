#!/usr/bin/env python3

DOCUMENTATION = '''
---
module: custom_esxi_hosts
short_description: Retrieve ESXi hosts from vCenter inventory
'''

from ansible.module_utils.basic import AnsibleModule
from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vim
import ssl

def main():
    module = AnsibleModule(
        argument_spec=dict(
            vcenter_host=dict(type='str', required=True),
            vcenter_user=dict(type='str', required=True),
            vcenter_password=dict(type='str', required=True, no_log=True)
        )
    )
    
    vcenter_host = module.params['vcenter_host']
    vcenter_user = module.params['vcenter_user']
    vcenter_password = module.params['vcenter_password']
    
    s = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
    s.verify_mode = ssl.CERT_NONE
    
    try:
        si = SmartConnect(host=vcenter_host, user=vcenter_user, pwd=vcenter_password, sslContext=s)
        content = si.content
        esxi_hosts = get_all_objs(content, [vim.HostSystem])
        esxi_host_info = []

        for esxi_host in esxi_hosts:
            host_name = esxi_host.name
            connection_status = check_connection_status(esxi_host)
            maintenance_mode = esxi_host.runtime.inMaintenanceMode
            power_state = esxi_host.runtime.powerState
            esxi_host_info.append({'name': host_name, 'connected': connection_status, 'maintenance_mode': maintenance_mode, 'power_state': power_state})

        Disconnect(si)
        
        response = {'esxi_hosts': esxi_host_info}
        module.exit_json(changed=False, meta=response)
    except Exception as e:
        module.fail_json(msg=str(e))

def get_all_objs(content, vimtype):
    obj = {}
    container = content.viewManager.CreateContainerView(content.rootFolder, vimtype, True)
    for managed_object_ref in container.view:
        obj.update({managed_object_ref: managed_object_ref.name})
    return obj

def check_connection_status(host):
    return host.runtime.connectionState == vim.HostSystemConnectionState.connected

if __name__ == "__main__":
    main()
